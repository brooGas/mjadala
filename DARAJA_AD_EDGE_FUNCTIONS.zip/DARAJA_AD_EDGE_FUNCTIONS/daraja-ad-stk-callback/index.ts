// Public webhook Safaricom calls directly with the STK push result.
// Set DARAJA_CALLBACK_URL (in the shared secrets) to this function's URL:
//   https://<project-ref>.functions.supabase.co/daraja-ad-stk-callback
// Deploy with --no-verify-jwt since Safaricom cannot send a Supabase JWT:
//   supabase functions deploy daraja-ad-stk-callback --no-verify-jwt
import { createClient } from "jsr:@supabase/supabase-js@2";

Deno.serve(async (req) => {
  try {
    const body = await req.json();
    const stk = body?.Body?.stkCallback;
    if (!stk) return new Response("ignored", { status: 200 });

    const checkoutRequestId = stk.CheckoutRequestID as string;
    const resultCode = String(stk.ResultCode);
    const items: any[] = stk.CallbackMetadata?.Item || [];
    const get = (name: string) => items.find((i) => i.Name === name)?.Value;
    const receipt = get("MpesaReceiptNumber");
    const amount = get("Amount");
    const phone = get("PhoneNumber");

    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    // Audit trail first (idempotent on checkout_request_id).
    await admin.from("mj_ad_mpesa_callback_events").upsert(
      {
        checkout_request_id: checkoutRequestId,
        merchant_request_id: stk.MerchantRequestID,
        result_code: resultCode,
        receipt_number: receipt ? String(receipt) : null,
        amount: amount ?? null,
        phone: phone ? String(phone) : null,
        callback_payload: body,
      },
      { onConflict: "checkout_request_id" },
    );

    // Then reflect the result on the campaign itself.
    await admin
      .from("mj_ad_campaigns")
      .update({
        payment_status: resultCode === "0" ? "paid" : "rejected",
        payment_reference: receipt ? String(receipt) : null,
        mpesa_result_code: resultCode,
      })
      .eq("mpesa_checkout_request_id", checkoutRequestId);

    return new Response(JSON.stringify({ ResultCode: 0, ResultDesc: "Accepted" }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("daraja-ad-stk-callback error:", err);
    // Always 200 so Safaricom doesn't endlessly retry a bad payload.
    return new Response(JSON.stringify({ ResultCode: 0, ResultDesc: "Accepted" }), {
      headers: { "Content-Type": "application/json" },
    });
  }
});
