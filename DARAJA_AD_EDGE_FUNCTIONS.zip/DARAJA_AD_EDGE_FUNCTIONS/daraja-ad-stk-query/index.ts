// Fallback poller: asks Safaricom directly for a campaign's payment status,
// in case the callback never arrives (sleeping phone, dropped webhook).
// Called from engineering.js as:
//   sb.functions.invoke('daraja-ad-stk-query', { body: { campaign_id } })
// Deploy: supabase functions deploy daraja-ad-stk-query
import { createClient } from "jsr:@supabase/supabase-js@2";
import { corsHeaders, stkQuery } from "../_shared/daraja.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const { campaign_id } = await req.json();
    if (!campaign_id) throw new Error("campaign_id is required.");

    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: campaign, error } = await admin
      .from("mj_ad_campaigns")
      .select("mpesa_checkout_request_id,payment_status")
      .eq("id", campaign_id)
      .maybeSingle();
    if (error) throw error;
    if (!campaign?.mpesa_checkout_request_id || campaign.payment_status !== "pending") {
      return new Response(JSON.stringify({ ok: true, unchanged: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const result = await stkQuery(campaign.mpesa_checkout_request_id);
    const code = String(result.ResultCode ?? "");
    if (code === "0") {
      await admin.from("mj_ad_campaigns").update({ payment_status: "paid", mpesa_result_code: code }).eq("id", campaign_id);
    } else if (code && code !== "1032") {
      // 1032 = request cancelled by user/still awaiting; anything else final = rejected.
      await admin.from("mj_ad_campaigns").update({ payment_status: "rejected", mpesa_result_code: code }).eq("id", campaign_id);
    }

    return new Response(JSON.stringify({ ok: true, result_code: code }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: String((err as Error).message || err) }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
