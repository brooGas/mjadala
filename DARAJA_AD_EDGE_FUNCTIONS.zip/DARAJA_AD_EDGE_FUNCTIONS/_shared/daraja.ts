// Shared Daraja (Safaricom M-Pesa) helpers for the Engineering ad payment
// functions. Uses the same secret names as a typical Mjadala Daraja setup —
// if your existing daraja-stk-push function (used for business orders)
// already has secrets set under different names, either rename these calls
// to match, or set these as additional secrets with `supabase secrets set`.
//
// Required secrets (Project Settings -> Edge Functions -> Secrets, or
// `supabase secrets set NAME=value`):
//   DARAJA_ENV                sandbox | production   (default: sandbox)
//   DARAJA_CONSUMER_KEY
//   DARAJA_CONSUMER_SECRET
//   DARAJA_SHORTCODE          your Paybill/Till (Lipa Na M-Pesa shortcode)
//   DARAJA_PASSKEY            Lipa Na M-Pesa Online passkey
//   DARAJA_CALLBACK_URL       https://<project-ref>.functions.supabase.co/daraja-ad-stk-callback
// These are always available automatically in an Edge Function:
//   SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY

export function env(name: string, fallback?: string): string {
  const v = Deno.env.get(name) ?? fallback;
  if (v === undefined) throw new Error(`Missing required secret: ${name}`);
  return v;
}

const BASE_URL = () =>
  env("DARAJA_ENV", "sandbox") === "production"
    ? "https://api.safaricom.co.ke"
    : "https://sandbox.safaricom.co.ke";

export async function getAccessToken(): Promise<string> {
  const key = env("DARAJA_CONSUMER_KEY");
  const secret = env("DARAJA_CONSUMER_SECRET");
  const auth = btoa(`${key}:${secret}`);
  const res = await fetch(`${BASE_URL()}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${auth}` },
  });
  if (!res.ok) throw new Error(`Daraja auth failed (${res.status}): ${await res.text()}`);
  const json = await res.json();
  return json.access_token as string;
}

function timestamp(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return (
    d.getFullYear().toString() +
    pad(d.getMonth() + 1) +
    pad(d.getDate()) +
    pad(d.getHours()) +
    pad(d.getMinutes()) +
    pad(d.getSeconds())
  );
}

export function normalizePhone(raw: string): string {
  let p = (raw || "").replace(/[^\d]/g, "");
  if (p.startsWith("0")) p = "254" + p.slice(1);
  if (p.startsWith("7") || p.startsWith("1")) p = "254" + p;
  if (!/^254\d{9}$/.test(p)) throw new Error("Enter a valid Safaricom phone number, e.g. 07XXXXXXXX.");
  return p;
}

export async function stkPush(opts: { phone: string; amount: number; accountRef: string; description: string }) {
  const shortcode = env("DARAJA_SHORTCODE");
  const passkey = env("DARAJA_PASSKEY");
  const ts = timestamp();
  const password = btoa(`${shortcode}${passkey}${ts}`);
  const token = await getAccessToken();
  const phone = normalizePhone(opts.phone);
  const amount = Math.max(1, Math.round(opts.amount));
  const res = await fetch(`${BASE_URL()}/mpesa/stkpush/v1/processrequest`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify({
      BusinessShortCode: shortcode,
      Password: password,
      Timestamp: ts,
      TransactionType: "CustomerPayBillOnline",
      Amount: amount,
      PartyA: phone,
      PartyB: shortcode,
      PhoneNumber: phone,
      CallBackURL: env("DARAJA_CALLBACK_URL"),
      AccountReference: opts.accountRef.slice(0, 20),
      TransactionDesc: opts.description.slice(0, 20),
    }),
  });
  const json = await res.json();
  if (!res.ok || json.ResponseCode !== "0") {
    throw new Error(json.errorMessage || json.ResponseDescription || `STK push failed (${res.status})`);
  }
  return json as { MerchantRequestID: string; CheckoutRequestID: string; CustomerMessage: string };
}

export async function stkQuery(checkoutRequestId: string) {
  const shortcode = env("DARAJA_SHORTCODE");
  const passkey = env("DARAJA_PASSKEY");
  const ts = timestamp();
  const password = btoa(`${shortcode}${passkey}${ts}`);
  const token = await getAccessToken();
  const res = await fetch(`${BASE_URL()}/mpesa/stkpushquery/v1/query`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify({
      BusinessShortCode: shortcode,
      Password: password,
      Timestamp: ts,
      CheckoutRequestID: checkoutRequestId,
    }),
  });
  return res.json();
}

export const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
