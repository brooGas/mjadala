// Starts a Safaricom STK push for a paid Engineering ad plan.
// Called from engineering.js as:
//   sb.functions.invoke('daraja-ad-stk-push', { body: { campaign_id, phone } })
// Deploy: supabase functions deploy daraja-ad-stk-push
import { createClient } from "jsr:@supabase/supabase-js@2";
import { corsHeaders, stkPush } from "../_shared/daraja.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const { campaign_id, phone } = await req.json();
    if (!campaign_id || !phone) throw new Error("campaign_id and phone are required.");

    // Verify the caller actually owns this campaign, using their own JWT
    // (so RLS applies) rather than trusting the client-supplied id blindly.
    const userClient = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: campaign, error: loadError } = await userClient
      .from("mj_ad_campaigns")
      .select("id,user_id,plan_id,payment_status,title,mj_ad_plans(price_kes,is_free,name)")
      .eq("id", campaign_id)
      .maybeSingle();
    if (loadError) throw loadError;
    if (!campaign) throw new Error("Campaign not found, or it is not yours.");
    const plan = (campaign as any).mj_ad_plans;
    if (!plan || plan.is_free || Number(plan.price_kes) <= 0) throw new Error("This plan does not require payment.");
    if (campaign.payment_status === "paid") throw new Error("This campaign is already marked paid.");

    const result = await stkPush({
      phone,
      amount: Number(plan.price_kes),
      accountRef: `ENG-${String(campaign_id).slice(0, 8)}`,
      description: `Mjadala ad: ${plan.name}`,
    });

    // Service-role client to write tracking fields regardless of RLS —
    // the advertiser's own session may not be allowed to set these columns.
    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { error: updateError } = await admin
      .from("mj_ad_campaigns")
      .update({
        payment_status: "pending",
        payment_phone: phone,
        mpesa_checkout_request_id: result.CheckoutRequestID,
        mpesa_merchant_request_id: result.MerchantRequestID,
        payment_initiated_at: new Date().toISOString(),
      })
      .eq("id", campaign_id);
    if (updateError) throw updateError;

    return new Response(
      JSON.stringify({ ok: true, customer_message: result.CustomerMessage || "Check your phone for the Safaricom prompt." }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: String((err as Error).message || err) }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
