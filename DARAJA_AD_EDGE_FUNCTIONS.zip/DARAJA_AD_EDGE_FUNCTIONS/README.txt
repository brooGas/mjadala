Engineering ad payments — M-Pesa STK push (Daraja)
====================================================

I can write and wire this code, but I cannot deploy it to your Supabase
project myself (I don't have your project's login/credentials). You or
whoever manages your Supabase project needs to do this one-time setup —
it's the same kind of deploy you already did for the business-order
STK push, just for ads.

1. Run MIGRATION_ENGINEERING_AD_DARAJA.sql in the Supabase SQL editor
   (after MIGRATION_ENGINEERING_ADS_AND_AVATARS.sql).

2. Copy this whole DARAJA_AD_EDGE_FUNCTIONS/ folder into your project's
   supabase/functions/ folder, so you end up with:
     supabase/functions/_shared/daraja.ts
     supabase/functions/daraja-ad-stk-push/index.ts
     supabase/functions/daraja-ad-stk-query/index.ts
     supabase/functions/daraja-ad-stk-callback/index.ts

3. Set these secrets (reuse the same Daraja app/shortcode you already use
   for business orders, if you have one):
     supabase secrets set DARAJA_ENV=sandbox
     supabase secrets set DARAJA_CONSUMER_KEY=xxxx
     supabase secrets set DARAJA_CONSUMER_SECRET=xxxx
     supabase secrets set DARAJA_SHORTCODE=xxxx
     supabase secrets set DARAJA_PASSKEY=xxxx
     supabase secrets set DARAJA_CALLBACK_URL=https://<project-ref>.functions.supabase.co/daraja-ad-stk-callback
   Switch DARAJA_ENV to "production" with your live shortcode when you're
   ready to take real payments.

4. Deploy:
     supabase functions deploy daraja-ad-stk-push
     supabase functions deploy daraja-ad-stk-query
     supabase functions deploy daraja-ad-stk-callback --no-verify-jwt
   (the callback must skip JWT verification — Safaricom calls it directly,
   with no Supabase session.)

That's it. Once deployed, picking a paid plan in "Promote in Engineering"
and entering a phone number will trigger a real STK push; the ad's
payment status updates itself from "pending" to "paid" (or "rejected")
as soon as Safaricom calls back — no admin action needed for that part.
The admin review panel still shows the plan, price and payment status
before Approve/Reject, and the manual "Mark paid / Mark unpaid" buttons
still work as a fallback for anyone who pays another way.

Until this is deployed, the "Pay with M-Pesa" step in the app fails
gracefully with a message telling the advertiser to pay manually and
enter their M-Pesa code instead — nothing breaks.
